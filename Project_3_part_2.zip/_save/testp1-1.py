#
# Simple python program, focusing on part 01 of project
#
# NOTE: an online Python system is avaliable @ https://www.onlinegdb.com/
#
print("**starting**")

i = 1
print(i)

i = i + 1
print(i)

print("**done**")
