x = "z"

if x < "c": 
    print("if")
    print("if again")
elif x == 0:
    print("elif")
    print("elif again")
    print("elif again")
    print("elif again")
    print("elif again")
    print("elif again")
    print("elif again")
else:
    print("else")
    print("else again")
    
print("done")
